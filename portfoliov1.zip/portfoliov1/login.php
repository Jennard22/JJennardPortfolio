<?php
  include("database.php");
  session_start();
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    
    <div class="wrapper"> 
  <div class="form-wrapper sign-in"> 
    <form action= "login.php" method= "post">
   <h2>Login </h2>
    <div class="input-group">
      <input type="text" name="username" placeholder="Username" required> 
    </div>
    <div class="input-group">
       <input type="password" name="password" placeholder="Password" required>
    </div>
    <button type="submit" name="submit" value="Log In" required> Login<br> 
    <div class="signUp-link"> 
    <p>Don't have an account? Click here to  <a href="index.php"> Sign up </a> </p>
    </div>
  </form>
  </div>
  </div>
</body>
</html>


<?php

     if(isset($_POST["submit"])){

     
        $username = $_POST["username"];
        $password = $_POST["password"];

        $sql = "SELECT  * FROM test_tbl WHERE username = '$username'";
         $result = mysqli_query($conn, $sql);


            if (mysqli_num_rows($result) > 0){ // will fetch the data and make it array 
              $row  = mysqli_fetch_assoc($result);    

             if(password_verify($password, $row["password"]))//mirrorring password
               { 
                  $_SESSION["username"]  = $row ["username"];    
                  $_SESSION["password"]  = $row ["password"];
                  
                  
                   header("Location: home.php");
                   if($_SESSION["username"] == "Jennard22"){
                    header("Location: resume.php");
                   }  
                }  
            }
            echo "<script> alert ('Invalid Credentials!') </script>";

    }
           
    




?>    