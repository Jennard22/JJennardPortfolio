<?php
  include("database.php");
  session_start();
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>goal </title>
  <link href="home.css" rel="stylesheet" type="text/css" />
  <script src="script.js"></script>
  <style>
   
  </style> 
</head>
<body>
         <nav class="navbar"> 
          <ul>
             <li><strong><a href="index.php"> Logout </a></li>
             <li><strong><strong><a href="about.php">About Me </a></li>
             <li><strong><a href="goal.php">Goal   </a></li>
             <li><strong><a href="home.php"> Home </a></li>
          </ul> 
         </nav>


         <div class="container">
            <div class="box"> 
            <h1> Welcome to my Portfolio! </h1>
             <p> <strong> Hii I'm Jennard and welcome to my personal website. Learn
             more about my background as an Individual and as a Programming Student. I am dedicated to continuous learning, with a focus on enhancing and improving my
             expertise in Coding. That's all for now Stay tuned for more updates and as always, Padayon at Lundagin mo Beybeh! </strong> </p>
            </div>
            </strong> </p>
            
            </div>
        </div>

       

    </body>
    </html>


        



   
      

 