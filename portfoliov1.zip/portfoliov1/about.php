<?php
  include("database.php");
  session_start();
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>about me </title>
  <link href="about.css" rel="stylesheet" type="text/css" />
  <script src="script.js"></script>
  <style>
   
  </style> 
</head>
<body>
         <nav class="navbar"> 
          <ul>
             <li><strong><a href="index.php"> Logout </a></li>
             <li><strong><strong><a href="about.php">About Me </a></li>
             <li><strong><a href="goal.php">Goal   </a></li>
             <li><strong><a href="home.php"> Home </a></li>
          </ul> 
         </nav>


         <div class="container">
            <div class="box"> 
            <img src="prof.jpg" alt="Jennardimg" width="300" height="300">
            <h1> Justin Jennard Jose</h1>
              <h2> (Jennard)</h2>
             <p> <strong> Hi, I'm Justin Jennard Jose, My Friends call me Jennard or Triple J. I am programming student from CIIT Senior High School. 
                I used to study at St. Paul College of Bocaue during my Junior High School and transferred to CIIT Senior High School to study programming. 
                One of the reasons why I chose the programming track is because I want to create my own game one day. I enjoy playing games in general,
                 such as Call of Duty and Valorant. I also have other hobbies; I build Gundams and cosplay.I am very Interested in Web Development and 
                 graphics designing for the reason it is fun and needs creativity.  </strong> </p>
            </div>
            </strong> </p>
            
            </div>
        </div>

       

    </body>
    </html>
