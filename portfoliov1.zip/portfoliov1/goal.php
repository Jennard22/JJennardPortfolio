<?php
  include("database.php");
  session_start();
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>goal </title>
  <link href="goal.css" rel="stylesheet" type="text/css" />
  <script src="script.js"></script>
  <style>
   
  </style> 
</head>
<body>
         <nav class="navbar"> 
          <ul>
             <li><strong><a href="index.php"> Logout </a></li>
             <li><strong><a href="about.php">About Me </a></li>
             <li><a href="goal.php">Goal   </a></li>
             <li><a href="home.php"> Home </a></li>
          </ul> 
         </nav>


         <div class="container">
            <div class="box"> 
              <h1> GOAL  </h1>
             <p> <strong> As of now. I'm focused on creating  a  website that is user-friendly. Looking ahead, I've got plans to create an RFID 
                system with a built-in campus check-in feature for CIIT Students . The idea is to make it way easier for students to do their daily  
                campus check-ins without the hassle of visiting the website every time, which can be inconvinient. I also plan to create my own platform-style 
                game based on my pets. Ever since I was a kid, I have always dreamed of creating my own game, and I am still holding onto that dream up to this day.
            </strong> </p>
            
            </div>
        </div>

       

    </body>
    </html>