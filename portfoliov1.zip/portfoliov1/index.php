<?php
  include ("database.php")
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login.css">
</head>  
<body>
<div class="wrapper">
    <div class="form-wrapper sign-in">
      <form action="index.php" method="post">
        <h2>SIGN UP </h2> <br> <br>
        <div class="input-group">
          <input type="text" name="username" placeholder="Username" required>
        </div>
        <div class="input-group">
          <input type="password" name="password" placeholder="Password" required>
        </div>
        <div class="input-group">
          <input type="text" name="favoritefood" placeholder="Favorite Food" required> <br>
        </div>
        <div class="input-group">
          <input type="text" name="favoritecolor" placeholder="Favorite Color" required> <br>
        </div>
        <div class="input-group">
          <input type="text" name="gradelevel" placeholder="Grade Level" required> <br>
        </div>
        <div class="button">
          <button type="submit" name="register" value="register" required> Register <br>
         </div>
         <div class="signUp-link"> 
    <p>have an account? Click here to  <a href="login.php">Login </a> </p>
    </div>
      </form>
    </div>
  </div>
</body>
</html>
  

<?php
    if (isset($_POST["register"]))// isset makes value true. input value = true
     {
           $password_hash = password_hash($_POST["password"],PASSWORD_DEFAULT);  //passowrd encrypts
           $username = $_POST ['username'];
           $favoritefood = $_POST ['favoritefood'];
           $favoritecolor = $_POST ['favoritecolor'];
           $gradelevel = $_POST ['gradelevel'];
           
          $sql = "SELECT * FROM test_tbl WHERE username = '$username'";  //for same username it will trigger
          $result = mysqli_query($conn, $sql);

           if (mysqli_num_rows($result) > 0 ) { //tells what number the data is on the row
               echo "<script>   alert('Username Taken!')  </script>";
            }else{
                $sql = "INSERT INTO test_tbl (username, password, favoritefood, favoritecolor, gradelevel)
                VALUES('$username', '$password_hash', '$favoritefood', '$favoritecolor', '$gradelevel')";
            $result = mysqli_query($conn, $sql);
            }
           

           header("Location: login.php");
   
        } 
?>