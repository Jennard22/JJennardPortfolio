

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>resume</title>
  <link href="resume.css" rel="stylesheet" type="text/css" />
</head>

<body>


 <div class="link"> <a href="home.php"> Home Page</a></li>  </div>   
 <div class="container"> 
 <div class="left_side">
  <div class="profile_text"> 
    <div class="imgbx"> 
      <img src="prof.jpg"> 
    </div>
    <h2> Justin Jennard Jose <br> <span> Programming Student </span></h2>
  </div>
   <div class="contactinfo"> 
    <h3 class="title"> Contact Info </h3>
     <ul>
       <li> 
       <span class="icon"> </span>
      <span class="text"> 0929 217 2973 </span>
       </li>
       <li> 
          <span class="icon"> </span>
         <span class="text"> justinjennardarcillajose@gmail.com </span>
          </li>
     </ul>
   </div>


  <div class="education"> 
  <h3 class="title"> Education  </h3>
    <ul>
       <li> 
        <h5> Elementay Graduate with 3.0 GPA </h5>
         <h4> St.Paul College of Bocaue </h4>
         <h4> S.Y 2018 - 2019 </h4>
          </li>
      <li> 
        <h5>  Junior Highschool Graduate with 3.7 GPA </h5>
         <h4> St.Paul College of Bocaue </h4>
         <h4> S.Y 2022 - 2023 </h4>
          </li>

            <li> 
              <h5> Senior High School </h5>
               <h4> CIIT College of Arts and Technology SHS  </h4>
               <h4> 2023 - Present </h4>
                </li>

      
     </ul>
  
  
  
  
  
  </div>





   

   
 </div>
  <div class="right_side">

    <div class="aboutme">  
     <h2 class="title1"> Career Summary    </h2>
        <P> A dependable individual that values teamwork and effective communication. Knowledgable in language such as HTML, CSS and Java.</P>
      </div>  
 
  <div class="about">  
 <h2 class="title2"><strong> Career Objective  </strong>   </h2>
    <P> I want to see myself working for a company that offers  good oppurtunity and provides space to gain more knowledge in Programming. I want to be the type of Programmer that will use my knowledge and ideas to make people's lives easier and accessible.</P>
  </div>  


   <div class ="skill"> 
   <div class="title3"> <h2> <strong> Skills    </strong>  </h3>   </div>

   <div class="skillsimg"> <img src="skills.png" > </div>
  </div>

<div class ="seminar">

  <h2> <strong>Recent Seminars Attended </strong>     </h2>
<li> Tao sa Tao: Mga Totoong Kwento ng Martial Law </li>
  <li> Career Development Lecture Series 2: Career Quest  </li>
  <li> Team Aguhon: Career in Work Modes </li>



</div>

<div class="hobby"> 

  <h2> <strong>Hobbies and Interest</strong>     </h2>
   <div class="interest">    <strong> <p> <l1>Gaming  </l1> <l2>Live-Streaming</l2> <l3>Cosplay</l3> <l4>Gunpla-Building </l4></strong></p> </div>

  
</div>



  
</div>




 

  
</body>

</html>