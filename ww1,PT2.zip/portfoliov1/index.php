<?php
  include ("database.php")
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
</head>  
<body>

<div class="wrapper">
    <div class="form-wrapper sign-in">
      <form action="index.php" method="post">
        <h2>SIGN UP </h2> <br> <br>
        <div class="input-group">
          <input type="email" name="email" placeholder="Email" required>
        </div>
        <div class="input-group">
          <input type="text" name="username" placeholder="Username" required>
        </div>
        <div class="input-group">
          <input type="password" name="password" placeholder="Password" required>
        </div>
        <div class="input-group">
          <input type="text" name="favoritefood" placeholder="Favorite Food" required> <br>
        </div>
        <div class="input-group">
          <input type="text" name="favoritecolor" placeholder="Favorite Color" required> <br>
        </div>
        <div class="input-group">
          <input type="text" name="gradelevel" placeholder="Grade Level" required> <br>
        </div>
        <div class="button">
          <button type="submit" name="register" value="register" required> Register <br>
         </div>
         <div class="signUp-link"> 
    <p>Have an account? Click here to  <a href="login.php">Login </a> </p>
    </div>
      </form>
    </div>
  </div>
</body>
</html>

<?php
    if (isset($_POST["register"])) { 
        $password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT); //password hash hides encrypts the password
        $email = $_POST['email'];
        $username = $_POST['username'];
        $favoritefood = $_POST['favoritefood'];
        $favoritecolor = $_POST['favoritecolor'];
        $gradelevel = $_POST['gradelevel'];

        $sql = "SELECT * FROM qa_tbl WHERE username = '$username'";
        $query = mysqli_query($conn, $sql);

        if (mysqli_num_rows($query) > 0) { //alertbox when the username is already used
            echo "<script>   alert('Username already Taken!')  </script>";
        } else { //will proceed to login once the data is correct 
            $sql = "INSERT INTO qa_tbl (email, username, password, favoritefood, favoritecolor, gradelevel)
            VALUES( '$email', '$username', '$password_hash', '$favoritefood', '$favoritecolor', '$gradelevel')";
            $result = mysqli_query($conn, $sql);

            if ($result) {// will lead here after signing up 
                header("Location: login.php");
            } else {
                echo "<script>   alert('Error: " . mysqli_error($conn) . "')  </script>";
            }
        }
    }
?>
